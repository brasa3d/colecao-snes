'use strict';
function startPerformanceCheck(emulator, output) {
  let previous = null;
  function sample() {
    const now = performance.now();
    const frame = emulator.gameManager.getFrameNum();
    if (document.hidden) {
      previous = null;
      return;
    }
    const context = emulator.Module?.AL?.currentCtx?.audioCtx;
    const state = context?.state || 'indisponível';
    const sound = {running: 'ativo', suspended: 'pausado', interrupted: 'interrompido', closed: 'fechado'}[state] || state;
    if (previous && frame >= previous.frame && now > previous.time && now - previous.time <= 5000) {
      const fps = Math.round((frame - previous.frame) * 1000 / (now - previous.time));
      output.textContent = `TESTE V10 · Jogo: ${fps} FPS · Som: ${sound}`;
    } else {
      output.textContent = `TESTE V10 · Medindo velocidade… · Som: ${sound}`;
    }
    previous = {time: now, frame};
  }
  sample();
  const timer = setInterval(sample, 2000);
  return () => clearInterval(timer);
}
